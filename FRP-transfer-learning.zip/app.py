# -*- coding: utf-8 -*-
# 依赖: pip install pandas numpy scikit-learn xgboost joblib openpyxl

import os
import sys
import json
import logging
import traceback
import threading
from pathlib import Path

import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from joblib import load

# ------------------------- 基础配置（按你的路径定制） -------------------------
APP_TITLE_ZH = "FRP 粘结强度预测（高温）"
APP_TITLE_EN = "FRP Bond Strength Prediction (High Temperature)"

# 直接指向你的 best_model/model.joblib
BEST_MODEL_FILE = r"A:\FRP迁移学习\软件\best_model\model.joblib"
BEST_MODEL_DIR = None  # 不使用目录自动搜索

LOG_FILE = "prediction_app.log"

# ------------------------- 日志与异常 -------------------------
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def except_hook(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    error_message = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    logging.error(f"未捕获的异常: {error_message}")
    try:
        messagebox.showerror("未捕获的异常", error_message)
    except Exception:
        pass

sys.excepthook = except_hook

# ------------------------- 加载模型 bundle -------------------------
def maybe_exp(y, use_log):
    return np.expm1(y) if use_log else y

def load_bundle(model_path: str):
    if not model_path or not os.path.exists(model_path):
        raise FileNotFoundError(f"未找到模型文件: {model_path}")
    bundle = load(model_path)
    required_keys = ['f_base', 'g_xgb', 'scaler_X', 'scaler_T', 'bias_b0', 'T0', 'USE_LOG_TARGET', 'feature_cols']
    missing = [k for k in required_keys if k not in bundle]
    if missing:
        raise ValueError(f"模型缺少必要字段: {missing}")
    return bundle

try:
    BUNDLE = load_bundle(BEST_MODEL_FILE)
    f_base = BUNDLE['f_base']
    g = BUNDLE['g_xgb']
    scaler_X = BUNDLE['scaler_X']
    scaler_T = BUNDLE['scaler_T']
    b0 = float(BUNDLE['bias_b0'])
    T0 = float(BUNDLE['T0'])
    USE_LOG_TARGET = bool(BUNDLE['USE_LOG_TARGET'])
    feature_columns = list(BUNDLE['feature_cols'])
    logging.info(f"成功加载 best model: {BEST_MODEL_FILE}")
    logging.info(f"特征顺序: {feature_columns}, T0={T0}, USE_LOG_TARGET={USE_LOG_TARGET}")
except Exception as e:
    message = f"加载模型失败: {e}"
    logging.error(message)
    try:
        messagebox.showerror("模型加载错误", message)
    except Exception:
        pass
    sys.exit(1)

# ------------------------- UI 展示名称（中英文映射，可按需修改） -------------------------
def zh_name(col):
    mapping = {
        'FT': 'FT',
        'FM': 'FM',
        'BS': 'BS',
        'd': '直径 d (mm)',
        'la': '搭接长度 la (mm)',
        'fc': '混凝土强度 fc (MPa)',
        'c_over_d': '保护层厚度比 c/d',
        'T': '温度 T (°C)'
    }
    return mapping.get(col, col)

def en_name(col):
    mapping = {
        'FT': 'FT',
        'FM': 'FM',
        'BS': 'BS',
        'd': 'Diameter d (mm)',
        'la': 'Lap length la (mm)',
        'fc': 'Concrete strength fc (MPa)',
        'c_over_d': 'Cover ratio c/d',
        'T': 'Temperature T (°C)'
    }
    return mapping.get(col, col)

def unit_of(col):
    if col in ['d', 'la']:
        return 'mm'
    if col in ['fc']:
        return 'MPa'
    if col == 'T':
        return '°C'
    return ''

# ------------------------- 推理函数 -------------------------
def build_Z_from_X_T(X, T_array):
    # X: (n, p) 原始特征，按 feature_columns 顺序
    # T_array: (n, 1) 温度
    yb_log = f_base.predict(X)  # 基线在 log 域的预测
    dT = T_array - T0
    dT2 = dT ** 2

    Xs = scaler_X.transform(X)
    dT_s = scaler_T.transform(dT)
    # 与训练时保持一致的标准化方式
    dT2_s = (dT2 - dT2.mean()) / (dT2.std() + 1e-8)

    k = min(3, Xs.shape[1])
    Z_list = [Xs, dT_s, dT2_s]
    if k > 0:
        Z_list.append(Xs[:, :k] * dT_s)
    Z = np.hstack(Z_list)
    return Z, yb_log

def predict_rows(df):
    # 期望 df 拥有 feature_columns（按列名）以及列 T
    missing = [c for c in feature_columns + ['T'] if c not in df.columns]
    if missing:
        raise ValueError(f"缺少必需列: {missing}")

    X = df[feature_columns].values
    T_vals = df['T'].astype(float).values.reshape(-1, 1)

    Z, yb_log = build_Z_from_X_T(X, T_vals)
    r_hat = g.predict(Z) + b0
    y_pred = maybe_exp(yb_log + r_hat, USE_LOG_TARGET)
    return y_pred

# ------------------------- 说明文本 -------------------------
def make_instructions(lang='zh'):
    feats = feature_columns.copy()
    if lang == 'zh':
        desc = []
        desc.append("输入特征与顺序要求:")
        for i, c in enumerate(feats, 1):
            desc.append(f"{i}. {zh_name(c)}  -> 列名: {c}")
        desc.append(f"{len(feats)+1}. 温度 T (°C) -> 列名: T")
        desc.append("")
        desc.append("输出:")
        desc.append("- 预测 τu (与训练目标一致的单位，通常为 MPa)")
        desc.append("")
        desc.append("批量预测 Excel 要求:")
        desc.append("- 建议包含表头（列名），程序将按列名匹配；也支持无表头。")
        desc.append("- 必须包含全部列名：")
        desc.append("  " + ", ".join(feats + ['T']))
        desc.append("- 若无表头，请确保列顺序严格为上述顺序。")
        desc.append("- 单位与训练数据保持一致（如 d、la 为 mm；fc、τu 为 MPa；T 为 °C）。")
        return "\n".join(desc)
    else:
        desc = []
        desc.append("Input features and order:")
        for i, c in enumerate(feats, 1):
            desc.append(f"{i}. {en_name(c)}  -> column: {c}")
        desc.append(f"{len(feats)+1}. Temperature T (°C) -> column: T")
        desc.append("")
        desc.append("Output:")
        desc.append("- Predicted τu (same unit as the training target, typically MPa)")
        desc.append("")
        desc.append("Batch Excel requirements:")
        desc.append("- Header row is recommended; columns are matched by names. No header is also supported.")
        desc.append("- Must contain all columns:")
        desc.append("  " + ", ".join(feats + ['T']))
        desc.append("- If no header, ensure the column order exactly matches the above.")
        desc.append("- Keep units consistent with training (e.g., d, la in mm; fc, τu in MPa; T in °C).")
        return "\n".join(desc)

# ------------------------- UI -------------------------
current_language = 'zh'

root = tk.Tk()
root.geometry("1200x800")
root.configure(bg="white")
root.title(APP_TITLE_ZH)

# 字体
FONT_YAHEI_NORMAL = ('微软雅黑', 12)
FONT_YAHEI_BOLD = ('微软雅黑', 12, 'bold')
FONT_YAHEI_TITLE = ('微软雅黑', 20, 'bold')
FONT_YAHEI_RESULT = ('微软雅黑', 16, 'bold')

FONT_TIMES_NORMAL = ('Times New Roman', 12)
FONT_TIMES_BOLD = ('Times New Roman', 12, 'bold')
FONT_TIMES_TITLE = ('Times New Roman', 20, 'bold')
FONT_TIMES_RESULT = ('Times New Roman', 16, 'bold')

# 主题
style = ttk.Style()
style.theme_use('default')
style.configure('TFrame', background="white")
style.configure('TLabel', background="white")
style.map('TCombobox', fieldbackground=[('readonly', 'white')])

# 顶部语言切换
lang_frame = ttk.Frame(root, style='TFrame')
lang_frame.pack(fill=tk.X, padx=10, pady=5)
lang_label = ttk.Label(lang_frame, text="语言:")
lang_label.pack(side=tk.LEFT, padx=(0, 5))
lang_var = tk.StringVar()
lang_combo = ttk.Combobox(lang_frame, textvariable=lang_var, values=['中文', 'English'], state="readonly", width=10)
lang_combo.pack(side=tk.LEFT)
lang_combo.set('中文')

# Notebook
notebook = ttk.Notebook(root)
notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

prediction_main_frame = ttk.Frame(notebook, style='TFrame')
notebook.add(prediction_main_frame, text="预测")

left_frame = ttk.Frame(prediction_main_frame, style='TFrame')
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 5), pady=10)

separator = ttk.Separator(prediction_main_frame, orient='vertical')
separator.pack(side=tk.LEFT, fill='y', pady=10)

right_frame = ttk.Frame(prediction_main_frame, style='TFrame')
right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 10), pady=10)

# 左侧：单条预测
single_title_label = tk.Label(left_frame, bg="white")
single_title_label.pack(pady=20)

center_single_frame = ttk.Frame(left_frame, style='TFrame')
center_single_frame.pack(expand=True)

input_frame = ttk.Frame(center_single_frame, padding="10 10 10 10", style='TFrame')
input_frame.pack()

variables = []
input_labels = []
input_entries = {}
unit_labels = []

# 生成输入：feature_columns + T
all_input_order = feature_columns + ['T']

for i, col in enumerate(all_input_order):
    label = ttk.Label(input_frame)
    label.grid(row=i, column=0, padx=10, pady=10, sticky='e')
    input_labels.append(label)

    entry = ttk.Entry(input_frame, width=30)
    entry.grid(row=i, column=1, padx=10, pady=10)
    variables.append(entry)
    input_entries[col] = entry

    u = unit_of(col)
    if u:
        unit_label = ttk.Label(input_frame, text=u)
        unit_label.grid(row=i, column=2, padx=10, pady=10, sticky='w')
        unit_labels.append(unit_label)

def do_single_predict():
    lang = translations[current_language]
    try:
        row = {}
        for col in all_input_order:
            s = input_entries[col].get().strip()
            if s == "":
                raise ValueError(f"空输入: {col}")
            row[col] = float(s)
        df = pd.DataFrame([row], columns=all_input_order)
        y_pred = predict_rows(df)
        pred_val = float(y_pred[0])
        result_label.config(text=f"{lang['result_prefix']}{pred_val:.4f}{lang['result_unit']}")
        logging.info(f"单条预测成功: {row} -> {pred_val:.4f}")
    except ValueError as ve:
        messagebox.showerror(lang["error_title"], f"{lang['error_input']}\n{ve}")
    except Exception as e:
        messagebox.showerror(lang["error_title"], f"{lang['error_occurred']} {str(e)}")

predict_button = ttk.Button(center_single_frame, command=do_single_predict)
predict_button.pack(pady=20)
result_label = tk.Label(center_single_frame, text="", bg="white")
result_label.pack(pady=20)

# 右侧：批量预测
batch_title_label = tk.Label(right_frame, bg="white")
batch_title_label.pack(pady=20)

center_batch_frame = ttk.Frame(right_frame, style='TFrame')
center_batch_frame.pack(expand=True)

selected_file = tk.StringVar()
file_frame = ttk.Frame(center_batch_frame, padding="10 10 10 10", style='TFrame')
file_frame.pack(pady=20)
file_label = ttk.Label(file_frame)
file_label.pack(side=tk.LEFT, padx=5)
file_entry = ttk.Entry(file_frame, textvariable=selected_file, width=40, state='readonly')
file_entry.pack(side=tk.LEFT, padx=5)

def browse_file():
    lang = translations[current_language]
    file_path = filedialog.askopenfilename(title=lang["select_file"], filetypes=[("Excel", "*.xlsx *.xls")])
    if file_path:
        selected_file.set(file_path)
        batch_status.config(text=lang["batch_status_select"])

browse_button = ttk.Button(file_frame, command=browse_file)
browse_button.pack(side=tk.LEFT, padx=5)

def batch_predict():
    lang = translations[current_language]
    file_path = selected_file.get()
    if not file_path:
        messagebox.showwarning(lang["warning_no_file"], lang["warning_no_file_msg"])
        return
    batch_button.config(state='disabled'); browse_button.config(state='disabled')
    batch_status.config(text=lang["batch_status_start"]); progress_bar.start()

    def run_prediction():
        try:
            batch_status.config(text=lang["batch_status_reading"])
            # 先尝试带表头读取
            try:
                df = pd.read_excel(file_path)
                has_header = True
            except Exception:
                df = pd.read_excel(file_path, header=None)
                has_header = False

            if has_header:
                missing = [c for c in feature_columns + ['T'] if c not in df.columns]
                if missing:
                    raise ValueError(f"Excel缺少列: {missing}\n请包含列名并与模型特征一致，或提供无表头且按顺序的文件。")
                df_use = df[feature_columns + ['T']].copy()
            else:
                need = len(feature_columns) + 1
                if df.shape[1] < need:
                    raise ValueError(f"Excel列数不足，至少需要 {need} 列（{len(feature_columns)} 个特征 + 1 列 T）。")
                df_use = df.iloc[:, :need].copy()
                df_use.columns = feature_columns + ['T']

            # 类型转换
            for c in feature_columns + ['T']:
                df_use[c] = pd.to_numeric(df_use[c], errors='raise')

            batch_status.config(text=lang["batch_status_predicting"])
            y_pred = predict_rows(df_use)
            out_df = df_use.copy()
            out_df['tau_u_pred'] = y_pred

            batch_status.config(text=lang["batch_status_saving"])
            base = os.path.basename(file_path)
            if base.lower().endswith(('.xlsx', '.xls')):
                base = os.path.splitext(base)[0] + "_pred.xlsx"
            initial_name = f"predicted_{base}"
            save_path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                                     filetypes=[("Excel", "*.xlsx *.xls")],
                                                     title=lang["success_save"],
                                                     initialfile=initial_name)
            if save_path:
                out_df.to_excel(save_path, index=False)
                messagebox.showinfo(lang["success"], f"{lang['success_save']}{save_path}")
                batch_status.config(text=lang["batch_status_initial"])
            else:
                batch_status.config(text="保存操作已取消。")
        except Exception as e:
            messagebox.showerror(lang["error_title"], f"{lang['error_occurred']} {str(e)}")
            batch_status.config(text=f"{lang['error_occurred']} {str(e)}")
        finally:
            progress_bar.stop(); batch_button.config(state='normal'); browse_button.config(state='normal')

    threading.Thread(target=run_prediction, daemon=True).start()

batch_button = ttk.Button(center_batch_frame, command=batch_predict)
batch_button.pack(pady=20)
batch_status = tk.Label(center_batch_frame, bg="white")
batch_status.pack(pady=10)
progress_bar = ttk.Progressbar(center_batch_frame, orient=tk.HORIZONTAL, length=400, mode='indeterminate')
progress_bar.pack(pady=10)

# 说明页
instructions_frame = ttk.Frame(notebook, padding="10 10 10 10", style='TFrame')
notebook.add(instructions_frame, text="使用说明")
instructions_text = tk.Text(instructions_frame, wrap=tk.WORD, relief="flat", bg="#f5f5f5")
instructions_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
scrollbar = ttk.Scrollbar(instructions_text, orient=tk.VERTICAL, command=instructions_text.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
instructions_text.configure(yscrollcommand=scrollbar.set)
instructions_text.config(state='disabled')

# ------------------------- 文案与语言切换 -------------------------
def generate_display_names(lang):
    if lang == 'zh':
        return [zh_name(c) for c in feature_columns] + [zh_name('T')]
    else:
        return [en_name(c) for c in feature_columns] + [en_name('T')]

def make_translations():
    return {
        'zh': {
            "language_name": "中文", "language_label": "语言:", "title": APP_TITLE_ZH,
            "tab_prediction": "预测", "tab_instructions": "使用说明",
            "section_title_single": "单个预测", "section_title_batch": "批量预测",
            "predict_button": "预测", "result_prefix": "预测 τu: ", "result_unit": " (MPa)",
            "select_file": "选择Excel文件:", "browse": "浏览",
            "batch_button": "运行批量预测", "batch_status_initial": "请选择一个Excel文件。",
            "batch_status_select": "文件已选择，准备预测。", "batch_status_start": "开始批量预测...",
            "batch_status_reading": "正在读取文件...", "batch_status_predicting": "正在进行预测...",
            "batch_status_saving": "正在保存结果...",
            "success_save": "批量预测完成，结果已保存到 ", "warning_no_file": "未选择文件",
            "warning_no_file_msg": "请选择一个Excel文件进行批量预测。", "error_input": "输入错误: 请确保所有字段包含有效数字。",
            "error_occurred": "发生错误:", "success": "成功", "error_title": "错误",
            "instructions_text": make_instructions('zh')
        },
        'en': {
            "language_name": "English", "language_label": "Language:", "title": APP_TITLE_EN,
            "tab_prediction": "Prediction", "tab_instructions": "Instructions",
            "section_title_single": "Individual Prediction", "section_title_batch": "Batch Prediction",
            "predict_button": "Predict", "result_prefix": "Predicted τu: ", "result_unit": " (MPa)",
            "select_file": "Select Excel File:", "browse": "Browse",
            "batch_button": "Run Batch Prediction", "batch_status_initial": "Please select an Excel file.",
            "batch_status_select": "File selected, ready to predict.", "batch_status_start": "Starting batch prediction...",
            "batch_status_reading": "Reading file...", "batch_status_predicting": "Making predictions...",
            "batch_status_saving": "Saving results...",
            "success_save": "Batch prediction complete. Results saved to ", "warning_no_file": "No File Selected",
            "warning_no_file_msg": "Please select an Excel file to perform batch prediction.", "error_input": "Input Error: Please ensure all fields contain valid numbers.",
            "error_occurred": "An error occurred:", "success": "Success", "error_title": "Error",
            "instructions_text": make_instructions('en')
        }
    }

translations = make_translations()

def switch_language(event=None):
    global current_language
    selected_lang_display = lang_var.get()
    new_lang = 'en' if selected_lang_display == 'English' else 'zh'
    if new_lang == current_language and event is not None:
        return
    current_language = new_lang
    lang_dict = translations[current_language]

    is_english = (current_language == 'en')
    font_normal = FONT_TIMES_NORMAL if is_english else FONT_YAHEI_NORMAL
    font_bold = FONT_TIMES_BOLD if is_english else FONT_YAHEI_BOLD
    font_title = FONT_TIMES_TITLE if is_english else FONT_YAHEI_TITLE
    font_result = FONT_TIMES_RESULT if is_english else FONT_YAHEI_RESULT

    # 全局样式
    style.configure('TLabel', background="white", font=font_bold)
    style.configure('TButton', font=font_bold)
    style.configure('TEntry', font=font_normal)
    style.configure('TCombobox', font=font_normal)

    # 窗口与标签
    root.title(lang_dict["title"])
    lang_label.config(text=lang_dict["language_label"], font=font_normal)
    lang_combo.config(font=font_normal)

    notebook.tab(prediction_main_frame, text=lang_dict["tab_prediction"])
    notebook.tab(instructions_frame, text=lang_dict["tab_instructions"])

    single_title_label.config(text=lang_dict["section_title_single"], font=font_title)
    batch_title_label.config(text=lang_dict["section_title_batch"], font=font_title)

    # 输入项名称
    display_names = generate_display_names(current_language)
    for i, label in enumerate(input_labels):
        label.config(text=display_names[i])

    predict_button.config(text=lang_dict["predict_button"])
    result_label.config(text="", font=font_result)

    file_label.config(text=lang_dict["select_file"])
    browse_button.config(text=lang_dict["browse"])
    batch_button.config(text=lang_dict["batch_button"])
    batch_status.config(text=lang_dict["batch_status_initial"], font=font_normal)

    instructions_text.config(state='normal', font=font_normal)
    instructions_text.delete('1.0', tk.END)
    instructions_text.insert(tk.END, lang_dict["instructions_text"])
    instructions_text.config(state='disabled')

lang_combo.bind("<<ComboboxSelected>>", switch_language)
switch_language()  # 初始化

root.mainloop()